// Conectar ao servidor Socket.IO
const socket = io();

// Elementos do DOM
const myCanvas = document.getElementById('myCanvas');
const opponentCanvas = document.getElementById('opponentCanvas');
const myCtx = myCanvas.getContext('2d');
const opponentCtx = opponentCanvas.getContext('2d');
const colorPicker = document.getElementById('colorPicker');
const brushSize = document.getElementById('brushSize');
const brushSizeValue = document.getElementById('brushSizeValue');
const eraserBtn = document.getElementById('eraserBtn');
const clearBtn = document.getElementById('clearBtn');
const statusElement = document.getElementById('status');
const statusText = document.getElementById('statusText');

// Estado do desenho
let isDrawing = false;
let currentColor = colorPicker.value;
let currentSize = brushSize.value;
let isEraser = false;

// Configurar contextos dos canvas
function setupCanvas(ctx) {
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
}

setupCanvas(myCtx);
setupCanvas(opponentCtx);

// Atualizar tamanho do pincel
brushSize.addEventListener('input', (e) => {
    currentSize = e.target.value;
    brushSizeValue.textContent = `${currentSize}px`;
});

// Atualizar cor
colorPicker.addEventListener('input', (e) => {
    currentColor = e.target.value;
    isEraser = false;
    eraserBtn.classList.remove('active');
});

// Borracha
eraserBtn.addEventListener('click', () => {
    isEraser = !isEraser;
    eraserBtn.classList.toggle('active');
});

// Limpar canvas
clearBtn.addEventListener('click', () => {
    myCtx.clearRect(0, 0, myCanvas.width, myCanvas.height);
    socket.emit('clear');
});

// Funções de desenho
function startDrawing(e) {
    isDrawing = true;
    draw(e);
}

function stopDrawing() {
    isDrawing = false;
    myCtx.beginPath();
}

function draw(e) {
    if (!isDrawing) return;

    const rect = myCanvas.getBoundingClientRect();
    const scaleX = myCanvas.width / rect.width;
    const scaleY = myCanvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    // Desenhar no meu canvas
    myCtx.lineWidth = currentSize;
    myCtx.strokeStyle = isEraser ? '#ffffff' : currentColor;
    myCtx.lineTo(x, y);
    myCtx.stroke();
    myCtx.beginPath();
    myCtx.moveTo(x, y);

    // Enviar para o servidor
    socket.emit('draw', {
        x: x,
        y: y,
        color: isEraser ? '#ffffff' : currentColor,
        size: currentSize
    });
}

// Event listeners para desenho
myCanvas.addEventListener('mousedown', startDrawing);
myCanvas.addEventListener('mousemove', draw);
myCanvas.addEventListener('mouseup', stopDrawing);
myCanvas.addEventListener('mouseout', stopDrawing);

// Suporte para touch (mobile)
myCanvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const mouseEvent = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY
    });
    myCanvas.dispatchEvent(mouseEvent);
});

myCanvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const mouseEvent = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY
    });
    myCanvas.dispatchEvent(mouseEvent);
});

myCanvas.addEventListener('touchend', (e) => {
    e.preventDefault();
    const mouseEvent = new MouseEvent('mouseup', {});
    myCanvas.dispatchEvent(mouseEvent);
});

// Socket.IO eventos
socket.on('waiting', (data) => {
    statusElement.className = 'status waiting';
    statusText.textContent = data.message;
});

socket.on('gameStart', (data) => {
    statusElement.className = 'status connected';
    statusText.textContent = '✅ Conectado! Jogo iniciado!';

    // Limpar ambos os canvas
    myCtx.clearRect(0, 0, myCanvas.width, myCanvas.height);
    opponentCtx.clearRect(0, 0, opponentCanvas.width, opponentCanvas.height);
});

socket.on('opponentDraw', (data) => {
    // Desenhar no canvas do oponente
    opponentCtx.lineWidth = data.size;
    opponentCtx.strokeStyle = data.color;
    opponentCtx.lineTo(data.x, data.y);
    opponentCtx.stroke();
    opponentCtx.beginPath();
    opponentCtx.moveTo(data.x, data.y);
});

socket.on('opponentClear', () => {
    opponentCtx.clearRect(0, 0, opponentCanvas.width, opponentCanvas.height);
});

socket.on('opponentDisconnected', (data) => {
    statusElement.className = 'status disconnected';
    statusText.textContent = data.message;

    // Limpar canvas do oponente
    opponentCtx.clearRect(0, 0, opponentCanvas.width, opponentCanvas.height);
});

socket.on('connect', () => {
    console.log('Conectado ao servidor!');
});

socket.on('disconnect', () => {
    statusElement.className = 'status disconnected';
    statusText.textContent = '❌ Desconectado do servidor';
});
