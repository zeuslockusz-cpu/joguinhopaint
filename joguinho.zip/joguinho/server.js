const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const path = require('path');

// Servir arquivos estáticos da pasta public
app.use(express.static(path.join(__dirname, 'public')));

// Gerenciamento de salas e jogadores
let waitingPlayer = null;
const rooms = new Map();

io.on('connection', (socket) => {
    console.log('Novo jogador conectado:', socket.id);

    // Tentar emparelhar jogadores
    if (waitingPlayer === null) {
        // Primeiro jogador - colocar em espera
        waitingPlayer = socket.id;
        socket.emit('waiting', { message: 'Aguardando outro jogador...' });
        console.log('Jogador em espera:', socket.id);
    } else {
        // Segundo jogador - criar sala
        const roomId = `room_${waitingPlayer}_${socket.id}`;
        const player1 = waitingPlayer;
        const player2 = socket.id;

        // Adicionar ambos os jogadores à sala
        io.sockets.sockets.get(player1).join(roomId);
        socket.join(roomId);

        // Armazenar informações da sala
        rooms.set(player1, { roomId, opponent: player2 });
        rooms.set(player2, { roomId, opponent: player1 });

        // Notificar ambos os jogadores que o jogo começou
        io.to(roomId).emit('gameStart', {
            message: 'Jogo iniciado! Desenhe no seu canvas.',
            roomId: roomId
        });

        console.log(`Sala criada: ${roomId} com jogadores ${player1} e ${player2}`);

        waitingPlayer = null;
    }

    // Receber eventos de desenho e enviar para o oponente
    socket.on('draw', (data) => {
        const playerRoom = rooms.get(socket.id);
        if (playerRoom) {
            // Enviar o desenho apenas para o oponente
            socket.to(playerRoom.opponent).emit('opponentDraw', data);
        }
    });

    // Limpar canvas
    socket.on('clear', () => {
        const playerRoom = rooms.get(socket.id);
        if (playerRoom) {
            socket.to(playerRoom.opponent).emit('opponentClear');
        }
    });

    // Desconexão
    socket.on('disconnect', () => {
        console.log('Jogador desconectado:', socket.id);

        // Se estava esperando, remover da espera
        if (waitingPlayer === socket.id) {
            waitingPlayer = null;
        }

        // Notificar oponente se estava em uma sala
        const playerRoom = rooms.get(socket.id);
        if (playerRoom) {
            const opponentSocket = io.sockets.sockets.get(playerRoom.opponent);
            if (opponentSocket) {
                opponentSocket.emit('opponentDisconnected', {
                    message: 'Oponente desconectou. Aguardando novo jogador...'
                });
                opponentSocket.leave(playerRoom.roomId);

                // Colocar oponente em espera
                waitingPlayer = playerRoom.opponent;
                rooms.delete(playerRoom.opponent);
            }
            rooms.delete(socket.id);
        }
    });
});

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

http.listen(PORT, HOST, () => {
    console.log(`🎮 Servidor rodando na porta ${PORT}`);
    console.log(`🌐 Host: ${HOST}`);
    console.log(`🌐 Acesse: http://localhost:${PORT}`);
});
