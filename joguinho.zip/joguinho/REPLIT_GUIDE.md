# 🔧 Guia Rápido - Deploy no Replit

## ✅ Arquivos Corrigidos

O servidor foi atualizado para funcionar corretamente no Replit:
- ✅ Servidor agora escuta em `0.0.0.0` (necessário para Replit)
- ✅ Configuração `.replit` otimizada
- ✅ Instalação automática de dependências

## 📋 Passo a Passo no Replit

### 1. Criar Novo Repl
1. Acesse [replit.com](https://replit.com)
2. Clique em **"+ Create Repl"**
3. Escolha **"Node.js"** como template
4. Nome: `multiplayer-paint-battle`
5. Clique em **"Create Repl"**

### 2. Upload dos Arquivos
Faça upload de TODOS estes arquivos:

```
📁 Raiz do projeto:
├── server.js          ⬅️ IMPORTANTE
├── package.json       ⬅️ IMPORTANTE
├── .replit           ⬅️ IMPORTANTE
├── .replit.nix       ⬅️ NOVO
├── .gitignore
└── 📁 public/
    ├── index.html    ⬅️ IMPORTANTE
    ├── style.css     ⬅️ IMPORTANTE
    └── game.js       ⬅️ IMPORTANTE
```

**ATENÇÃO:** Certifique-se de criar a pasta `public` e colocar os 3 arquivos dentro dela!

### 3. Verificar Estrutura
No Replit, você deve ver esta estrutura de pastas:
```
joguinho/
├── server.js
├── package.json
├── .replit
├── .replit.nix
└── public/
    ├── index.html
    ├── style.css
    └── game.js
```

### 4. Rodar o Projeto
1. Clique no botão verde **"Run"** ▶️
2. Aguarde a instalação das dependências (pode demorar 30-60 segundos)
3. Você verá no console:
   ```
   🎮 Servidor rodando na porta 3000
   🌐 Host: 0.0.0.0
   ```
4. Uma janela do navegador abrirá automaticamente com o jogo

### 5. Compartilhar com Amigo
1. Copie a URL que aparece no topo (exemplo: `https://multiplayer-paint-battle.seu-usuario.repl.co`)
2. Envie para seu amigo
3. Quando ambos acessarem, o jogo começará!

## 🐛 Solução de Problemas

### Problema: "O servidor fecha logo após iniciar"
**Solução:**
- ✅ Verifique se o arquivo `server.js` foi atualizado com `HOST = '0.0.0.0'`
- ✅ Certifique-se de que a pasta `public` existe e contém os 3 arquivos
- ✅ Clique em "Shell" no Replit e execute: `npm install`
- ✅ Depois execute: `npm start`

### Problema: "Cannot find module 'express'"
**Solução:**
- Abra o Shell no Replit
- Execute: `npm install`
- Depois clique em "Run" novamente

### Problema: "Página não carrega"
**Solução:**
- Verifique se a pasta `public` está no lugar correto
- Verifique se `index.html`, `style.css` e `game.js` estão dentro de `public`
- Reinicie o Repl (Stop + Run)

### Problema: "Aguardando outro jogador..." não sai
**Solução:**
- Isso é normal! Você precisa de 2 pessoas conectadas
- Abra a URL em outra aba OU
- Envie a URL para um amigo

## 🎯 Testando Localmente Primeiro

Se quiser testar no seu computador antes de fazer upload no Replit:

```bash
# No terminal (já está rodando!)
# Abra http://localhost:3000 em 2 abas diferentes
```

## 📱 Dica: Testar Sozinho

Para testar se está funcionando:
1. Abra a URL do Replit em uma aba
2. Abra a MESMA URL em outra aba (Ctrl+T)
3. Agora você tem 2 "jogadores"
4. Desenhe em uma aba e veja aparecer na outra!

## ✅ Checklist Final

Antes de compartilhar com seu amigo:
- [ ] Servidor rodando sem erros
- [ ] Página carrega corretamente
- [ ] Testou com 2 abas e funcionou
- [ ] Desenho sincroniza entre as abas
- [ ] Todas as ferramentas funcionam (cores, tamanhos, borracha, limpar)

---

**Pronto! Agora é só jogar! 🎨🎮**
