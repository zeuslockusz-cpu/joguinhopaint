# 🎨 Multiplayer Paint Battle

Um jogo multiplayer em tempo real onde dois jogadores podem desenhar na tela um do outro simultaneamente!

## 🚀 Como Usar no Replit

### Passo 1: Criar Novo Repl
1. Acesse [Replit](https://replit.com)
2. Clique em **"+ Create Repl"**
3. Escolha **"Import from GitHub"** OU **"Node.js"**

### Passo 2: Fazer Upload dos Arquivos
Se escolheu "Node.js":
1. Faça upload de todos os arquivos deste projeto
2. Mantenha a estrutura de pastas:
   ```
   joguinho/
   ├── server.js
   ├── package.json
   ├── .replit
   └── public/
       ├── index.html
       ├── style.css
       └── game.js
   ```

### Passo 3: Rodar o Projeto
1. Clique no botão **"Run"** no topo
2. O Replit instalará as dependências automaticamente
3. Aguarde o servidor iniciar
4. Copie a URL que aparece (algo como `https://seu-projeto.seu-usuario.repl.co`)

### Passo 4: Jogar com um Amigo
1. Abra a URL em uma aba do navegador
2. Envie a mesma URL para seu amigo
3. Quando ambos acessarem, o jogo começará automaticamente!
4. Desenhe no canvas esquerdo e veja aparecer no canvas direito do seu amigo

## 🎮 Como Jogar

- **Seu Canvas (Esquerda)**: Desenhe aqui - aparece na tela do oponente
- **Canvas do Oponente (Direita)**: O oponente desenha aqui
- **Ferramentas**:
  - 🎨 Seletor de cores
  - 📏 Tamanho do pincel (1-50px)
  - 🧹 Borracha
  - 🗑️ Limpar canvas

## 🛠️ Tecnologias Utilizadas

- **Backend**: Node.js + Express + Socket.IO
- **Frontend**: HTML5 Canvas + JavaScript
- **Real-time**: WebSocket (Socket.IO)
- **Design**: CSS3 com Glassmorphism

## 📝 Estrutura do Projeto

- `server.js` - Servidor Express com Socket.IO para comunicação em tempo real
- `package.json` - Dependências do projeto
- `.replit` - Configuração do Replit
- `public/index.html` - Interface do jogo
- `public/style.css` - Estilos modernos com gradientes e animações
- `public/game.js` - Lógica do jogo e sincronização

## 🔧 Rodar Localmente (Opcional)

Se quiser rodar no seu computador:

```bash
# Instalar dependências
npm install

# Iniciar servidor
npm start

# Acessar em http://localhost:3000
```

## 🌟 Recursos

✅ Multiplayer em tempo real  
✅ Emparelhamento automático de jogadores  
✅ Desenho sincronizado instantaneamente  
✅ Múltiplas cores e tamanhos de pincel  
✅ Borracha e função limpar  
✅ Design moderno e responsivo  
✅ Suporte para touch (mobile)  
✅ Indicadores de status de conexão  

## 🎨 Divirta-se desenhando!
